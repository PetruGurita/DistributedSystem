import java.util.concurrent.TimeUnit;

public class Receive implements Commands{

	private int registerIndex;
	
	public Receive(int registerIndex) {
		
		this.registerIndex = registerIndex;
	}
	
	@Override
	public void execute(Process p) {
		// TODO Auto-generated method stub
		try {

			Object o = Main.communicationChannel[p.getProcessIndex()].poll(1L, TimeUnit.SECONDS);
			
			if (o != null)
				p.setRegisterValue(registerIndex, (Integer) o);
			else p.setDeadlock();
		}
		catch (InterruptedException e) {
			e.getMessage();
		}
		
	}

}
