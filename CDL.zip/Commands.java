public interface Commands {

	public void execute(Process p);
}
