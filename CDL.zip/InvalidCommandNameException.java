public class InvalidCommandNameException extends Exception{
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCommandNameException(String message)
     {
        super(message);
     }
}
